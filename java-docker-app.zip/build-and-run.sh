#!/bin/bash

# Build and run Java Docker application

echo "Building Docker image..."
docker build -t java-docker-app:latest .

echo "Running Docker container..."
docker run -d \
  --name java-docker-app \
  -p 8080:8080 \
  java-docker-app:latest

echo "Application is starting..."
echo "Access the application at: http://localhost:8080"
echo "Health check: http://localhost:8080/actuator/health"

# Wait for application to start
sleep 10

# Test the application
echo "Testing application..."
curl -s http://localhost:8080/ | head -n 5

echo ""
echo "Container logs:"
docker logs java-docker-app --tail 10