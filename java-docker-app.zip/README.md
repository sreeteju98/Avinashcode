# Java Docker Application

A simple Spring Boot application containerized with Docker.

## Project Structure

```
java-docker-app/
├── src/
│   └── main/
│       ├── java/com/example/
│       │   ├── Application.java
│       │   └── controller/HelloController.java
│       └── resources/
│           └── application.properties
├── Dockerfile
├── docker-compose.yml
├── pom.xml
└── README.md
```

## Features

- Spring Boot REST API
- Health check endpoint
- Multi-stage Docker build
- Docker Compose configuration
- Security best practices (non-root user)

## API Endpoints

- `GET /` - Welcome message
- `GET /hello/{name}` - Personalized greeting
- `GET /health` - Application health status
- `GET /actuator/health` - Spring Boot actuator health

## Quick Start

### Using Docker

1. Build and run:
   ```bash
   # Linux/Mac
   chmod +x build-and-run.sh
   ./build-and-run.sh
   
   # Windows
   build-and-run.bat
   ```

2. Or manually:
   ```bash
   docker build -t java-docker-app .
   docker run -p 8080:8080 java-docker-app
   ```

### Using Docker Compose

```bash
docker-compose up --build
```

### Local Development

```bash
mvn spring-boot:run
```

## Testing

Access the application:
- http://localhost:8080
- http://localhost:8080/hello/world
- http://localhost:8080/actuator/health

## Docker Commands

```bash
# Build image
docker build -t java-docker-app .

# Run container
docker run -d -p 8080:8080 --name java-app java-docker-app

# View logs
docker logs java-app

# Stop and remove
docker stop java-app && docker rm java-app
```